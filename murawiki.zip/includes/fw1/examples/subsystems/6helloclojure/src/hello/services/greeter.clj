(ns hello.services.greeter)

(defn hello [s] (str "Hello " s "!"))
